const products = {
  watchProducts: [
    ["Classic Gold Watch", 12500, "https://images.unsplash.com/photo-1523275335684-37898b6baf30"],
    ["Silver Premium Watch", 10900, "https://images.unsplash.com/photo-1533139502658-0198f920d8e8"],
    ["Minimal Black Watch", 8750, "https://images.unsplash.com/photo-1524592094714-0f0654e20314"],
    ["Luxury Steel Watch", 15300, "https://images.unsplash.com/photo-1547996160-81dfa63595aa"]
  ],

  shoeProducts: [
    ["Premium Red Sneaker", 6800, "https://images.unsplash.com/photo-1542291026-7eec264c27ff"],
    ["White Street Sneaker", 5450, "https://images.unsplash.com/photo-1549298916-b41d501d3772"],
    ["Modern Running Shoe", 4900, "https://images.unsplash.com/photo-1608231387042-66d1773070a5"],
    ["Luxury Casual Shoe", 7250, "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519"]
  ],

  bagProducts: [
    ["Elegant Brown Bag", 9250, "https://images.unsplash.com/photo-1594223274512-ad4803739b7c"],
    ["Luxury Handbag", 11400, "https://images.unsplash.com/photo-1584917865442-de89df76afd3"],
    ["Classic Black Bag", 8900, "https://images.unsplash.com/photo-1590874103328-eac38a683ce7"],
    ["Premium Travel Bag", 13700, "https://images.unsplash.com/photo-1553062407-98eeb64c6a62"]
  ],

  shirtProducts: [
    ["White Basic T-Shirt", 2400, "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab"],
    ["Black Oversize T-Shirt", 2800, "https://images.unsplash.com/photo-1503341504253-dff4815485f1"],
    ["Premium Cotton T-Shirt", 3100, "https://images.unsplash.com/photo-1576566588028-4147f3842f27"],
    ["Luxury Street T-Shirt", 3500, "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a"]
  ]
};

let cart = [];

function showPage(pageId) {
  document.querySelectorAll(".page").forEach(page => {
    page.classList.remove("active");
  });

  document.getElementById(pageId).classList.add("active");

  document.getElementById("categoryMenu").classList.remove("active");
  document.getElementById("userMenu").classList.remove("active");

  window.scrollTo(0, 0);
}

function toggleCategoryMenu() {
  document.getElementById("categoryMenu").classList.toggle("active");
  document.getElementById("userMenu").classList.remove("active");
}

function toggleUserMenu() {
  document.getElementById("userMenu").classList.toggle("active");
  document.getElementById("categoryMenu").classList.remove("active");
}

function formatPrice(price) {
  return "₺" + price.toLocaleString("tr-TR");
}

function loadProducts() {
  for (let category in products) {
    const container = document.getElementById(category);

    products[category].forEach(product => {
      container.innerHTML += `
        <div class="product-card">
          <img src="${product[2]}" alt="${product[0]}">
          <h3>${product[0]}</h3>
          <p class="price">${formatPrice(product[1])}</p>
          <button onclick="addToCart('${product[0]}', ${product[1]}, '${product[2]}')">
            Sepete Ekle
          </button>
        </div>
      `;
    });
  }
}

function addToCart(name, price, image) {
  cart.push({ name, price, image });
  updateCart();

  const oldPopup = document.getElementById("cartPopup");
  if (oldPopup) {
    oldPopup.remove();
  }

  const popup = document.createElement("div");
  popup.className = "cart-popup";
  popup.id = "cartPopup";

  popup.innerHTML = `
    <img src="${image}" alt="${name}">
    
    <div class="popup-info">
      <h3>${name}</h3>
      <p>${formatPrice(price)}</p>

      <div class="popup-buttons">
        <button onclick="closePopup()">Devam Et</button>
        <button class="checkout-btn" onclick="goToCart()">Sepete Git</button>
      </div>
    </div>
  `;

  document.body.appendChild(popup);

  setTimeout(() => {
    popup.classList.add("active");
  }, 10);
}

function closePopup() {
  const popup = document.getElementById("cartPopup");

  if (popup) {
    popup.remove();
  }
}

function goToCart() {
  closePopup();
  showPage("cart");
}

function updateCart() {
  const cartItems = document.getElementById("cartItems");
  const cartTotal = document.getElementById("cartTotal");
  const cartCount = document.getElementById("cartCount");

  cartItems.innerHTML = "";

  let total = 0;

  if (cart.length === 0) {
    cartItems.innerHTML = "<p class='empty-cart'>Sepetiniz şu an boş.</p>";
  }

  cart.forEach((item, index) => {
    total += item.price;

    cartItems.innerHTML += `
      <div class="cart-item">
        <img src="${item.image}" alt="${item.name}">

        <div>
          <h3>${item.name}</h3>
          <p>${formatPrice(item.price)}</p>
        </div>

        <button class="remove-btn" onclick="removeFromCart(${index})">Sil</button>
      </div>
    `;
  });

  cartTotal.textContent = formatPrice(total);
  cartCount.textContent = cart.length;
}

function removeFromCart(index) {
  cart.splice(index, 1);
  updateCart();
}

function showCheckout() {
  if (cart.length === 0) {
    alert("Sepetiniz boş.");
    return;
  }

  document.getElementById("checkoutBox").classList.add("active");
  window.scrollTo(0, document.body.scrollHeight);
}

function completeOrder() {
  alert("Siparişiniz başarıyla oluşturuldu. Teşekkürler!");

  cart = [];
  updateCart();

  document.getElementById("checkoutBox").classList.remove("active");
  showPage("home");
}

loadProducts();
updateCart();